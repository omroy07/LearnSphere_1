# import tkinter as tk
# from tkinter import scrolledtext

# def get_bot_response(user_input):
#     responses = {
#         "hi": "Hello! How can I assist you today?",
#         "hello": "Hi there! What do you need help with?",
#         "what is physics": "Physics is the branch of science concerned with the nature and properties of matter and energy.",
#         "who are you": "I am your learning assistant, here to help you with your studies!",
#     }
#     return responses.get(user_input.lower(), "I'm not sure about that. Can you rephrase?")

# def send_message():
#     user_input = input_box.get("1.0", tk.END).strip()
#     if user_input:
#         chat_history.config(state=tk.NORMAL)
#         chat_history.insert(tk.END, f"You: {user_input}\n", "user")
#         bot_response = get_bot_response(user_input)
#         chat_history.insert(tk.END, f"Bot: {bot_response}\n", "bot")
#         chat_history.config(state=tk.DISABLED)
#         input_box.delete("1.0", tk.END)

# # Create main window
# root = tk.Tk()
# root.title("Learn Sphere Chatbot")
# root.geometry("500x600")
# root.configure(bg="#1E1E1E")

# # Chat history display
# chat_history = scrolledtext.ScrolledText(root, state=tk.DISABLED, wrap=tk.WORD, bg="#252526", fg="white", font=("Arial", 12))
# chat_history.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
# chat_history.tag_configure("bot", foreground="cyan")
# chat_history.tag_configure("user", foreground="lightgreen")

# # Input box
# input_box = tk.Text(root, height=3, bg="#333333", fg="white", font=("Arial", 12))
# input_box.pack(padx=10, pady=(0,10), fill=tk.BOTH)

# # Send button
# send_button = tk.Button(root, text="Send", command=send_message, bg="#007ACC", fg="white", font=("Arial", 12))
# send_button.pack(pady=10)

# # Start bot with welcome message
# chat_history.config(state=tk.NORMAL)
# chat_history.insert(tk.END, "Bot: Welcome to The Learn Sphere\n", "bot")
# chat_history.config(state=tk.DISABLED)

# root.mainloop()

# import tkinter as tk
# from tkinter import scrolledtext
# import requests

# def get_bot_response(user_input):
#     api_url = "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"  
#     payload = {"message": user_input}
#     response = requests.post(api_url, json=payload)
#     if response.status_code == 200:
#         return response.json().get("reply", "I'm not sure about that. Can you rephrase?")
#     else:
#         return "Sorry, I am having trouble connecting to the server."

# def send_message():
#     user_input = input_box.get("1.0", tk.END).strip()
#     if user_input:
#         chat_history.config(state=tk.NORMAL)
#         chat_history.insert(tk.END, f"You: {user_input}\n", "user")
#         bot_response = get_bot_response(user_input)
#         chat_history.insert(tk.END, f"Bot: {bot_response}\n", "bot")
#         chat_history.config(state=tk.DISABLED)
#         input_box.delete("1.0", tk.END)

# # Create main window
# root = tk.Tk()
# root.title("Peer Learning Chatbot")
# root.geometry("500x600")
# root.configure(bg="#1E1E1E")

# # Chat history display
# chat_history = scrolledtext.ScrolledText(root, state=tk.DISABLED, wrap=tk.WORD, bg="#252526", fg="white", font=("Arial", 12))
# chat_history.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
# chat_history.tag_configure("bot", foreground="cyan")
# chat_history.tag_configure("user", foreground="lightgreen")

# # Input box
# input_box = tk.Text(root, height=3, bg="#333333", fg="white", font=("Arial", 12))
# input_box.pack(padx=10, pady=(0,10), fill=tk.BOTH)

# # Send button
# send_button = tk.Button(root, text="Send", command=send_message, bg="#007ACC", fg="white", font=("Arial", 12))
# send_button.pack(pady=10)

# # Start bot with welcome message
# chat_history.config(state=tk.NORMAL)
# chat_history.insert(tk.END, "Bot: Welcome to The Digital Peer Learning Hub!\n", "bot")
# chat_history.config(state=tk.DISABLED)

# root.mainloop()
import tkinter as tk
from tkinter import scrolledtext
import google.generativeai as genai

# Configure Gemini API
genai.configure(api_key="AIzaSyA6eZooGrs3BTSwAcIcIaLukh8H97EFV2o")

def get_bot_response(user_input):
    try:
        model = genai.GenerativeModel("gemini-pro")
        response = model.generate_content(user_input)
        return response.text if response else "Sorry, I couldn't generate a response."
    except Exception as e:
        return f"Error: {str(e)}"

def send_message():
    user_input = input_box.get("1.0", tk.END).strip()
    if user_input:
        chat_history.config(state=tk.NORMAL)
        chat_history.insert(tk.END, f"You: {user_input}\n", "user")
        bot_response = get_bot_response(user_input)
        chat_history.insert(tk.END, f"Bot: {bot_response}\n", "bot")
        chat_history.config(state=tk.DISABLED)
        input_box.delete("1.0", tk.END)

# Create main window
root = tk.Tk()
root.title("Peer Learning Chatbot")
root.geometry("500x600")
root.configure(bg="#1E1E1E")

# Chat history display
chat_history = scrolledtext.ScrolledText(root, state=tk.DISABLED, wrap=tk.WORD, bg="#252526", fg="white", font=("Arial", 12))
chat_history.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
chat_history.tag_configure("bot", foreground="cyan")
chat_history.tag_configure("user", foreground="lightgreen")

# Input box
input_box = tk.Text(root, height=3, bg="#333333", fg="white", font=("Arial", 12))
input_box.pack(padx=10, pady=(0,10), fill=tk.BOTH)

# Send button
send_button = tk.Button(root, text="Send", command=send_message, bg="#007ACC", fg="white", font=("Arial", 12))
send_button.pack(pady=10)

# Start bot with welcome message
chat_history.config(state=tk.NORMAL)
chat_history.insert(tk.END, "Bot: Welcome to The Digital Peer Learning Hub!\n", "bot")
chat_history.config(state=tk.DISABLED)

root.mainloop()